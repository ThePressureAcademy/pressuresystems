/* global React */
// Strategy assets: captions, CTA bank, design system, claim-boundary checklist,
// production checklist, short-form cutdowns, master strategy notes.
// These render as wider artboards (1200x… variable) to read like documents.

const STRATEGY_W = 1200;

// ---------- shared "doc" page chrome ----------
function DocPage({ title, kicker, children, height = 1500 }) {
  return (
    <div className="dt-slide" data-screen-label={title} style={{ width: STRATEGY_W, height }}>
      <div className="dt-head">
        <span><span className="dot" />DispatchTalon</span>
        <span className="dt-num">{kicker}</span>
      </div>
      <div className="dt-body" style={{ paddingBottom: 120 }}>
        <Eyebrow>{kicker}</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 36, fontSize: 56 }}>{title}</h2>
        {children}
      </div>
      <div className="dt-foot">
        <span>DispatchTalon <strong>by Pressure Systems</strong></span>
        <span>Internal · do not publish raw</span>
      </div>
    </div>
  );
}

// ---------- Master strategy ----------
function MasterStrategy() {
  return (
    <DocPage title="Master carousel strategy" kicker="Strategy · 01" height={1900}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 28 }}>
        {[
          ["Audience", "Operations managers, dispatch managers, crane company owners, labour allocators, plant managers."],
          ["Voice", "Operational, low fluff. Direct sentences. No hype, no AI-power claims, no compliance promises."],
          ["Frame", "Category: dispatch intelligence for labour and lifting operations. Not a generic SaaS."],
          ["Mechanism", "Pain → consequence → mechanism → boundary → CTA. Hormozi structure under Voss empathy."],
          ["Motif language", "Decision node (rust), dispatch path (line), audit trail (dots), block/warn/review tags, before/after columns."],
          ["Trust posture", "Dispatcher remains decision-maker. Pilot-stage. No autonomous dispatch. No permit / compliance claim."],
          ["First slide rule", "Pattern-interrupt headline, no body copy, watermark visible, max 8 words ideal."],
          ["Last slide rule", "CTA only. One primary, one secondary. No new claims on the CTA slide."]
        ].map(([k, v], i) => (
          <div key={i} className="dt-panel" style={{ padding: 24 }}>
            <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--rust)" }}>{String(i+1).padStart(2,"0")} · {k.toUpperCase()}</div>
            <div className="dt-body-text" style={{ fontSize: 19, marginTop: 10, color: "var(--cream)" }}>{v}</div>
          </div>
        ))}
      </div>
      <h3 className="dt-h3" style={{ marginTop: 48, fontSize: 30 }}>Priority order</h3>
      <div className="dt-mono" style={{ marginTop: 16, fontSize: 15, color: "var(--steel)", letterSpacing: "0.06em" }}>
        For cold LinkedIn traffic, sequence carousels in this order:
      </div>
      <ol style={{ marginTop: 14, paddingLeft: 24, fontFamily: "var(--font-display)", fontSize: 22, color: "var(--cream)", lineHeight: 1.7 }}>
        <li><span className="dt-rust">C2 — The Dispatcher Still Decides.</span> Boundary first. Defuses AI scepticism on day one.</li>
        <li><span className="dt-rust">C1 — Rough Job Notes Become Dispatch Risk.</span> Concrete pain. Highest forward share rate expected.</li>
        <li><span className="dt-rust">C4 — Why Allocation Decisions Need a Trail.</span> Commercial buyer hook. "What if someone asks?"</li>
        <li>C5 — SmartRank Is Not Magic AI. Re-frames the buzzword.</li>
        <li>C7 — Plant Numbers Matter. Highly specific to crane/plant audience.</li>
        <li>C8 — Counterweight and Transport. Senior crane operator authority signal.</li>
        <li>C3 — Operating Modes. For when traffic asks "does it fit us?"</li>
        <li>C6 — Build My Business. For warm traffic / retargeting.</li>
      </ol>
    </DocPage>
  );
}

// ---------- LinkedIn captions ----------
const CAPTIONS = [
  {
    n: 1, title: "C1 · Job intake",
    body: `Most dispatch problems do not start on site.

They start in the gap between a phone call, an SMS, and a half-typed email — long before anyone signs in.

DispatchTalon parses pasted text, .txt, and .md briefs into a structured job, then puts the dispatcher in front of every suggested field before the job exists.

Less retyping. More review before dispatch.

A 15-minute walkthrough is here if it sounds familiar: [link]

#dispatch #labourhire #crane #rigging #liftingoperations`
  },
  {
    n: 2, title: "C2 · Dispatcher decides",
    body: `Every "AI dispatch" pitch should answer one question:

Who confirms the worker?

In DispatchTalon, that is the dispatcher. Every time.

The system structures the decision — worker fit, credentials, fatigue, schedule, blocks, warnings, override reasons — and the human confirms. The audit trail is what the system writes after the decision, not before it.

Better clarity, not blind automation.

[link to walkthrough]

#dispatch #operations #cranehire`
  },
  {
    n: 3, title: "C3 · Operating modes",
    body: `Labour-only and plant + labour operations do not have the same dispatch screen.

If you do not run plant, you should not be staring at asset fields.
If you do, those fields should carry plant numbers, travel state, and counterweight context — not just "100T crane".

DispatchTalon ships in two modes and builds the portal around how your business actually works.

Discovery call: [link]

#labour #plant #crane #dispatch`
  },
  {
    n: 4, title: "C4 · Audit trail",
    body: `"Why was this worker selected?"

In most businesses, the answer lives in someone's head. That works until the day changes, pressure rises, or a client asks.

DispatchTalon records the path: job requirements → warnings → SmartRank → overrides → allocation. The trail does not remove judgement. It preserves it.

Better evidence. Better review. Better handover.

[link]

#operations #audit #dispatch #crane`
  },
  {
    n: 5, title: "C5 · SmartRank",
    body: `SmartRank is not magic AI.

It ranks workers against a job — roles, credentials, fatigue, schedule, preferences, requirements — and shows blocks, warnings, and reasons in plain sight.

The dispatcher still decides what to do next. The score is a starting point for the conversation, not the conversation itself.

Walkthrough: [link]

#dispatchintelligence #labour #rigging`
  },
  {
    n: 6, title: "C6 · Build My Business",
    body: `Most dispatch tools open with an empty database and a 200-field form.

DispatchTalon opens with Build My Business — pick labour-only or plant + labour, enable the credentials and assets your business actually uses, and your first job is structured around that.

A managed pilot, not cheap self-serve software.

Send context first: [link]

#onboarding #operations #crane`
  },
  {
    n: 7, title: "C7 · Plant numbers",
    body: `A job does not always need "a crane".

It may need MC20-001, with the extra counterweight already fitted, parked in the south yard.

DispatchTalon keeps the class and the plant number separate — and lets both sit on the allocation. Audit trail preserves the link.

That is allocation clarity.

[link]

#planthire #crane #assetregister`
  },
  {
    n: 8, title: "C8 · Counterweight + transport",
    body: `Counterweight assumptions should not live in someone's head.

Crane class is only part of the picture. Travel state, counterweight gap, support transport, and road-access prompts each deserve their own review point.

DispatchTalon surfaces these as flags before dispatch. It does not approve permits, and it does not engineer lifts. It creates a structured review point so the conversation happens before the truck leaves.

[link]

#crane #lifting #nhvr #dispatch`
  }
];

function Captions() {
  return (
    <DocPage title="LinkedIn captions" kicker="Captions · 8 carousels" height={2900}>
      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        {CAPTIONS.map((c) => (
          <div key={c.n} className="dt-panel" style={{ padding: 28 }}>
            <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--rust)" }}>{c.title.toUpperCase()}</div>
            <div className="dt-body-text" style={{ fontSize: 18, lineHeight: 1.55, marginTop: 14, whiteSpace: "pre-wrap", color: "var(--cream)" }}>
              {c.body}
            </div>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

// ---------- CTA bank ----------
function CtaBank() {
  const ctas = [
    ["Primary", "Book a DispatchTalon discovery call", "Calendly · /thepressureacademy/liftiq-discovery"],
    ["Primary", "Send context first", "/liftiq/contact/ — for buyers who want to brief before they book"],
    ["Soft", "Watch the portal walkthrough", "Anchor on the home page (pending publish)"],
    ["Soft", "See the module status and boundaries", "/liftiq/modules/"],
    ["Soft", "See how DispatchTalon fits the workflow", "/liftiq/how-it-works/"],
    ["Carousel-specific · C1", "See how a rough note becomes a structured job", "Use on slide 8 of C1"],
    ["Carousel-specific · C2", "Walk through the review-before-dispatch screen", "Use on slide 8 of C2"],
    ["Carousel-specific · C3", "See how the operating modes differ", "Use on slide 8 of C3"],
    ["Carousel-specific · C4", "See the audit trail walkthrough", "Use on slide 8 of C4"],
    ["Carousel-specific · C5", "Walk through SmartRank on a real allocation", "Use on slide 8 of C5"],
    ["Carousel-specific · C7", "See the asset register on a plant + labour job", "Use on slide 8 of C7"],
    ["Carousel-specific · C8", "See the crane review panel on a real job", "Use on slide 8 of C8"]
  ];
  return (
    <DocPage title="CTA bank" kicker="CTAs · approved" height={1800}>
      <div className="dt-panel inset" style={{ padding: 0 }}>
        {ctas.map(([type, label, route], i) => (
          <div key={i} style={{ padding: "20px 28px", borderBottom: i < ctas.length - 1 ? "1px solid var(--hairline)" : "none", display: "flex", alignItems: "center", gap: 22 }}>
            <span style={{ flex: "0 0 220px", fontFamily: "var(--font-mono)", fontSize: 13, letterSpacing: "0.12em", color: "var(--steel)", textTransform: "uppercase" }}>{type}</span>
            <span style={{ flex: 1, color: "var(--cream)", fontSize: 20 }}>{label}</span>
            <span style={{ flex: "0 0 360px", fontFamily: "var(--font-mono)", fontSize: 14, color: "var(--rust)" }}>{route}</span>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

// ---------- Claim-boundary checklist ----------
function ClaimBoundaries() {
  const items = [
    ["Allowed", "Structures the decision before dispatch"],
    ["Allowed", "Decision-support / dispatcher remains decision-maker"],
    ["Allowed", "Surfaces blocks, warnings, and review flags"],
    ["Allowed", "Records override reasons in the audit trail"],
    ["Allowed", "Pilot-stage workflow · managed pilot"],
    ["Allowed", "Tenant-isolated pilot access"],
    ["Forbidden", "Autonomous dispatch · sends workers automatically"],
    ["Forbidden", "\"Safe to dispatch\" / \"compliance approved\" / \"permit ready\""],
    ["Forbidden", "Compliance guarantee or WHS / legal claim"],
    ["Forbidden", "Permit approval, lift engineering, load-chart calculation"],
    ["Forbidden", "Route optimisation or live external integration claim"],
    ["Forbidden", "Replaces dispatcher / removes the human"],
    ["Forbidden", "AI-powered everything / revolutionary / game-changing"],
    ["Forbidden", "Old LIFTIQ branding or rejected claw-style marks"]
  ];
  return (
    <DocPage title="Claim-boundary checklist" kicker="QA · trust architecture" height={1800}>
      <div className="dt-panel inset" style={{ padding: 0 }}>
        {items.map(([type, label], i) => (
          <div key={i} style={{ padding: "18px 28px", borderBottom: i < items.length - 1 ? "1px solid var(--hairline)" : "none", display: "flex", alignItems: "center", gap: 22 }}>
            <span style={{ flex: "0 0 130px", fontFamily: "var(--font-mono)", fontSize: 13, letterSpacing: "0.12em", color: type === "Allowed" ? "var(--ok)" : "var(--block)", textTransform: "uppercase" }}>{type}</span>
            <span style={{ flex: 1, color: "var(--cream)", fontSize: 20 }}>{label}</span>
          </div>
        ))}
      </div>
      <div className="dt-mono" style={{ marginTop: 28, fontSize: 14, letterSpacing: "0.08em", color: "var(--steel)" }}>
        Run this list against every caption AND every slide before publishing.
      </div>
    </DocPage>
  );
}

// ---------- Production checklist ----------
function ProductionChecklist() {
  return (
    <DocPage title="Designer production checklist" kicker="Production · pre-export" height={1700}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 22 }}>
        {[
          ["01 Type", "Space Grotesk 400/500/600. IBM Plex Mono 400/500. No system substitutes."],
          ["02 Colour", "#0E1216 / #F2F0E6 / #6B7077 / #E2712A. Rust reserved for decision-node + accents only."],
          ["03 Watermark", "Locked DispatchTalon header-mark PNG, top-right corner @ 64px / opacity 0.7. \"Huge\" 720px variant only on slide 1 as bg device. Never recolour, redraw, or replace with a stand-in."],
          ["04 Slide 1", "Title only. No CTA. No body copy. Decision-node motif present."],
          ["05 Last slide", "Single primary + single ghost CTA. No new claims."],
          ["06 Footer", "\"DispatchTalon by Pressure Systems · Pilot-stage workflow · Dispatcher-led review\" on every slide."],
          ["07 Decision node", "Rust only. Outlined node = step marker. Solid node = decision point."],
          ["08 Tags", "block · warn · rust · ok. Use only one solid CTA per slide."],
          ["09 Export", "1080×1350 PNG per slide. Square crops at 1080×1080 with safe centre 1080×900."],
          ["10 Naming", "carousel-XX/slide-YY.png — zero-padded."],
          ["11 Alt text", "Functional description, no marketing copy. Mention motif (e.g. \"audit ticker\")."],
          ["12 QA pass", "Cross-check captions, claim boundaries, and slide copy. No \"safe to dispatch\"."]
        ].map(([k, v], i) => (
          <div key={i} className="dt-panel" style={{ padding: 22 }}>
            <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--rust)" }}>{k}</div>
            <div className="dt-body-text" style={{ fontSize: 17, marginTop: 10, color: "var(--cream)" }}>{v}</div>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

// ---------- Short-form cutdowns ----------
function ShortForm() {
  const ideas = [
    ["C1 · 12s reel", "Phone screen with 4 incoming messages stacking on top of each other → cut to DispatchTalon Job Brief Import field grid filling in. Voice-over: \"Most allocation problems start before anyone leaves the yard.\""],
    ["C2 · 8s static motion", "Two-column type animation. Left column: SYSTEM / Structures / Shows / Records. Right column: DISPATCHER / Reviews / Decides / Confirms. End card: \"The human still confirms.\""],
    ["C4 · 15s audit reel", "Camera pans down the audit ticker on slide 4 of C4, line by line, then end card: \"The trail does not remove judgement. It preserves it.\""],
    ["C5 · 10s SmartRank reel", "Candidate cards fall into position #1 / #2 / #3 / #4, with block / warn / clear tags appearing on each. End: \"Reasons are visible.\""],
    ["C7 · 9s plant-number reel", "Class \"20T Mobile Crane\" splits visually into MC20-001, MC20-002, MC20-003. Stamp \"Allocation clarity.\""],
    ["C8 · 14s counterweight reel", "Plain text whiteboard \"100T\" wipes off → replaced with REVIEW · COUNTERWEIGHT card. Voice: \"Counterweight assumptions shouldn't live on a whiteboard.\""]
  ];
  return (
    <DocPage title="Short-form cutdowns" kicker="Reels · 8–15s" height={1900}>
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {ideas.map(([k, v], i) => (
          <div key={i} className="dt-panel" style={{ padding: 24 }}>
            <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--rust)" }}>{k}</div>
            <div className="dt-body-text" style={{ fontSize: 18, marginTop: 10, color: "var(--cream)", lineHeight: 1.5 }}>{v}</div>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

// ---------- Reuse / crop guidance ----------
function ReuseGuide() {
  return (
    <DocPage title="Crop & reuse guidance" kicker="Channels · re-purpose" height={1600}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 22 }}>
        {[
          ["LinkedIn carousel", "1080×1350 native. Upload as multi-image PDF or document post for full vertical."],
          ["LinkedIn square fallback", "1080×1080 crop. Keep all type within centre 1080×900 safe area. Cut the foot strip if needed — re-stamp on the right edge."],
          ["Instagram", "1080×1350 fits 4:5 natively. Use slide 1 + slide 8 as a 2-slide story arc."],
          ["Website hero band", "Re-skin slide 4 of any carousel into a horizontal 1920×600 banner. Keep grid + decision-node motif, drop the head/foot chrome."],
          ["Email signature", "Slide 1 of each carousel as a 600×600 footer card with link to that carousel's landing page."],
          ["Sales follow-up PDF", "Compile all 8 carousels into a single A4 PDF (one slide per page). Add a contact page at the end."],
          ["Investor / grant deck", "Cherry-pick slides 1, 4, 5 of C2 + slides 1, 4, 7 of C4 to demonstrate trust architecture and audit posture."],
          ["Reel cover frame", "Use the bigMark slide-1 layout, with the reel hook copy replacing the carousel headline."]
        ].map(([k, v], i) => (
          <div key={i} className="dt-panel" style={{ padding: 22 }}>
            <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--rust)" }}>{k}</div>
            <div className="dt-body-text" style={{ fontSize: 17, marginTop: 10, color: "var(--cream)" }}>{v}</div>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

// ---------- Asset gap report ----------
function AssetGaps() {
  return (
    <DocPage title="Outstanding screenshots & assets" kicker="QA · what's still placeholder" height={1500}>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {[
          ["C1 · slide 6", "Real Job Brief Import field grid screenshot — replace mocked field list."],
          ["C2 · slide 5", "Real override-reason capture modal — current text is illustrative."],
          ["C4 · slide 4", "Real audit ticker export from pilot tenant — current rows are illustrative."],
          ["C5 · slide 4", "Real SmartRank candidate list — current names are illustrative."],
          ["C5 · slide 6", "Real expanded-candidate detail panel."],
          ["C6 · slide 3", "Real company-requirement catalogue screen."],
          ["C6 · slide 4", "Real worker import / list view."],
          ["C7 · slide 5", "Real asset register table from pilot tenant."],
          ["C8 · slides 4–6", "Real crane-review panel with counterweight, transport, road-access prompts."]
        ].map(([k, v], i) => (
          <div key={i} style={{ padding: "16px 22px", border: "1px solid var(--hairline)", borderRadius: 4, display: "flex", gap: 22, alignItems: "flex-start" }}>
            <span style={{ flex: "0 0 160px", fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 14, letterSpacing: "0.1em" }}>{k.toUpperCase()}</span>
            <span style={{ flex: 1, fontSize: 18, color: "var(--cream-dim)" }}>{v}</span>
          </div>
        ))}
      </div>
      <div className="dt-mono" style={{ marginTop: 24, fontSize: 14, letterSpacing: "0.08em", color: "var(--steel)" }}>
        Until these arrive, layouts use the dt-shot striped placeholder + structured mock data. All placeholders are pilot-realistic, not aspirational.
      </div>
    </DocPage>
  );
}

// ---------- Design system card ----------
function DesignSystemCard() {
  return (
    <DocPage title="Design system" kicker="Tokens · motifs · locked brand assets" height={2100}>
      <h3 className="dt-h3" style={{ fontSize: 26 }}>Locked brand assets</h3>
      <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.08em", color: "var(--steel)", marginTop: 8 }}>
        Source: assets/logos/dispatchtalon/ — imported from ThePressureAcademy/pressuresystems
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 24, marginTop: 18 }}>
        <div className="dt-panel" style={{ padding: 22, display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <img src={TALON_MARK_SRC} alt="" style={{ width: 180, height: 180, objectFit: "contain" }} />
          <div className="dt-mono" style={{ fontSize: 12, letterSpacing: "0.1em", color: "var(--steel)" }}>HEADER MARK · 394×394 PNG</div>
        </div>
        <div className="dt-panel" style={{ padding: 22, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center" }}>
          <img src={TALON_PRIMARY_LOCKUP_SRC} alt="" style={{ width: "100%", height: "auto", maxHeight: 200, objectFit: "contain" }} />
          <div className="dt-mono" style={{ fontSize: 12, letterSpacing: "0.1em", color: "var(--steel)", marginTop: 8 }}>PRIMARY LOCKUP · 1400×420 PNG</div>
        </div>
      </div>

      <h3 className="dt-h3" style={{ marginTop: 40, fontSize: 26 }}>Palette</h3>
      <div style={{ display: "flex", gap: 14, marginTop: 16 }}>
        {[
          ["Charcoal", "#0E1216", "var(--charcoal)"],
          ["Cream", "#F2F0E6", "var(--cream)"],
          ["Steel", "#6B7077", "var(--steel)"],
          ["Rust", "#E2712A", "var(--rust)"]
        ].map(([n, h, v]) => (
          <div key={n} style={{ flex: 1 }}>
            <div style={{ height: 110, background: v, borderRadius: 4, border: "1px solid var(--hairline)" }} />
            <div className="dt-mono" style={{ marginTop: 10, color: "var(--cream)", fontSize: 14, letterSpacing: "0.08em" }}>{n.toUpperCase()}</div>
            <div className="dt-mono" style={{ color: "var(--steel)", fontSize: 13 }}>{h}</div>
          </div>
        ))}
      </div>

      <h3 className="dt-h3" style={{ marginTop: 40, fontSize: 26 }}>Type</h3>
      <div className="dt-panel" style={{ marginTop: 14, padding: 24 }}>
        <div className="dt-display sm" style={{ fontSize: 48 }}>Space Grotesk · headline</div>
        <div className="dt-body-text" style={{ marginTop: 8 }}>Space Grotesk · body / lead</div>
        <div className="dt-mono" style={{ marginTop: 8 }}>IBM PLEX MONO · LABELS / AUDIT / TECHNICAL</div>
      </div>

      <h3 className="dt-h3" style={{ marginTop: 40, fontSize: 26 }}>Motif kit</h3>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginTop: 14 }}>
        <div className="dt-panel" style={{ padding: 22, alignItems: "center", display: "flex", flexDirection: "column", gap: 12 }}>
          <Node size="sm">·</Node>
          <div className="dt-mono" style={{ fontSize: 13, color: "var(--steel)", letterSpacing: "0.1em" }}>DECISION NODE</div>
        </div>
        <div className="dt-panel" style={{ padding: 22, alignItems: "center", display: "flex", flexDirection: "column", gap: 12 }}>
          <Trail on={4} total={7} />
          <div className="dt-mono" style={{ fontSize: 13, color: "var(--steel)", letterSpacing: "0.1em" }}>AUDIT TRAIL</div>
        </div>
        <div className="dt-panel" style={{ padding: 22, alignItems: "center", display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", gap: 6 }}>
            <Tag tone="block">BLOCK</Tag>
            <Tag tone="warn">WARN</Tag>
            <Tag tone="rust">REVIEW</Tag>
          </div>
          <div className="dt-mono" style={{ fontSize: 13, color: "var(--steel)", letterSpacing: "0.1em" }}>FLAG TAGS</div>
        </div>
      </div>
    </DocPage>
  );
}

// ---------- Locked brand kit gallery ----------
function BrandKit() {
  const items = [
    ["dispatchtalon-primary-lockup.png", "Primary horizontal lockup", "1400×420", "Website hero, sales deck, proposal cover, email footer"],
    ["dispatchtalon-website-header-lockup.png", "Website header lockup", "900×270", "Public website navigation (baked dark bg)"],
    ["dispatchtalon-header-lockup-transparent.png", "Header lockup · transparent", "779×240", "Dark-surface fallback / portal login"],
    ["dispatchtalon-portal-login-lockup.png", "Portal login lockup", "1100×340", "Console login screen"],
    ["dispatchtalon-primary-mark.png", "Primary icon mark", "768×768", "Brand guide, pitch deck, large brand panel"],
    ["dispatchtalon-header-mark-transparent.png", "Header mark · transparent (LOCKED watermark)", "394×394", "Portal topbar, subtle dark-surface watermark — used on every carousel slide"],
    ["dispatchtalon-monochrome-light.png", "Monochrome · light", "768×768", "Dark dashboard header, single-colour print"],
    ["dispatchtalon-monochrome-dark.png", "Monochrome · dark", "768×768", "Light document background"],
    ["dispatchtalon-linkedin-ad-corner-mark.png", "LinkedIn ad corner mark", "720×220", "Ad-board brand corner, campaign creative"],
    ["dispatchtalon-app-icon-512.png", "App icon · 512", "512×512", "Web manifest, portal favicon source"],
    ["dispatchtalon-favicon-192.png", "Favicon · 192", "192×192", "PWA icon"],
    ["dispatchtalon-social-avatar.png", "Social avatar", "1024×1024", "LinkedIn / profile crop"]
  ];
  return (
    <DocPage title="Locked brand kit" kicker="Brand · do-not-redraw" height={2400}>
      <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.08em", color: "var(--steel)", marginBottom: 22 }}>
        Source of truth: <span style={{ color: "var(--rust)" }}>assets/logos/dispatchtalon/</span> · imported from ThePressureAcademy/pressuresystems@main · do not regenerate, recolour, or redraw any item below.
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        {items.map(([file, name, dims, use], i) => (
          <div key={file} className="dt-panel" style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
            <div style={{ background: "var(--charcoal-deep)", height: 180, display: "flex", alignItems: "center", justifyContent: "center", padding: 18 }}>
              <img src={"assets/logos/dispatchtalon/" + file} alt={name} style={{ maxHeight: "100%", maxWidth: "100%", objectFit: "contain" }} />
            </div>
            <div style={{ padding: "18px 22px", borderTop: "1px solid var(--hairline)" }}>
              <div className="dt-mono" style={{ fontSize: 12, letterSpacing: "0.1em", color: "var(--rust)" }}>{dims}</div>
              <div className="dt-h3" style={{ fontSize: 20, marginTop: 6 }}>{name}</div>
              <div className="dt-body-text" style={{ fontSize: 15, marginTop: 6, color: "var(--cream-dim)" }}>{use}</div>
              <div className="dt-mono" style={{ fontSize: 11, color: "var(--steel)", marginTop: 8, letterSpacing: "0.04em" }}>{file}</div>
            </div>
          </div>
        ))}
      </div>
    </DocPage>
  );
}

window.STRATEGY = {
  MasterStrategy,
  Captions,
  CtaBank,
  ClaimBoundaries,
  ProductionChecklist,
  ShortForm,
  ReuseGuide,
  AssetGaps,
  DesignSystemCard,
  BrandKit
};
