/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock */
// Carousel 5 — SmartRank Is Not Magic AI

const C5_TOTAL = 8;

function C5S1() {
  return (
    <Slide carousel={5} slideNum={1} total={C5_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>05 · SmartRank</Eyebrow>
        <h1 className="dt-display lg">
          SmartRank<br/>is not <span className="dt-rust">magic AI.</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          It is a structured ranking of your workers against the job context. The reasoning is visible. The dispatcher decides.
        </p>
      </div>
    </Slide>
  );
}

function C5S2() {
  return (
    <Slide carousel={5} slideNum={2} total={C5_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What it actually does</Eyebrow>
        <h2 className="dt-display md">
          Ranks <span className="dt-rust">workers</span><br/>against the <span className="dt-rust">job context.</span>
        </h2>
        <div style={{ marginTop: 80, display: "flex", alignItems: "center", gap: 36 }}>
          <div style={{ textAlign: "center" }}>
            <div className="dt-mono" style={{ color: "var(--steel)", letterSpacing: "0.14em", marginBottom: 14 }}>WORKERS</div>
            <div className="dt-h3" style={{ fontSize: 30, color: "var(--cream)" }}>Tickets<br/>Fatigue<br/>Schedule<br/>Preferences</div>
          </div>
          <span style={{ color: "var(--rust)", fontFamily: "var(--font-mono)", fontSize: 36 }}>×</span>
          <div style={{ textAlign: "center" }}>
            <div className="dt-mono" style={{ color: "var(--steel)", letterSpacing: "0.14em", marginBottom: 14 }}>JOB CONTEXT</div>
            <div className="dt-h3" style={{ fontSize: 30, color: "var(--cream)" }}>Roles<br/>Credentials<br/>Site conditions<br/>Schedule</div>
          </div>
          <span style={{ color: "var(--rust)", fontFamily: "var(--font-mono)", fontSize: 36 }}>=</span>
          <div className="dt-tag rust" style={{ height: 64, fontSize: 22, padding: "0 28px" }}>Ranked list</div>
        </div>
      </div>
    </Slide>
  );
}

function C5S3() {
  return (
    <Slide carousel={5} slideNum={3} total={C5_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What it weighs</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 48 }}>Six signals. Nothing hidden.</h2>
        <div className="dt-panel inset" style={{ padding: 0 }}>
          {[
            ["Roles", "Does the worker hold the role this job needs?"],
            ["Credentials", "Tickets and VOCs valid for this job."],
            ["Fatigue", "Hours worked and rest history."],
            ["Schedule", "Conflicts with other jobs in window."],
            ["Preferences", "Civil, rail, energy, height — worker preference."],
            ["Requirements", "Selected, suggested, and one-off requirements."]
          ].map(([k, v], i) => (
            <div key={i} className="dt-row" style={{ padding: "24px 32px" }}>
              <span style={{ flex: "0 0 60px", fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 18 }}>0{i + 1}</span>
              <span style={{ flex: "0 0 240px", fontFamily: "var(--font-mono)", fontSize: 16, letterSpacing: "0.1em", color: "var(--cream)", textTransform: "uppercase" }}>{k}</span>
              <span style={{ color: "var(--cream-dim)", fontSize: 22 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C5S4() {
  const cands = [
    { rank: 1, name: "L. Henderson", note: "All credentials current · within fatigue window", tone: "ok" },
    { rank: 2, name: "S. Marriot", note: "Ticket valid · prefers civil work", tone: "ok" },
    { rank: 3, name: "B. Tahi", note: "Fatigue warning · 11 hrs yesterday", tone: "warn" },
    { rank: 4, name: "K. Pollard", note: "BLOCK · HRWL expired 3 days ago", tone: "block" }
  ];
  return (
    <Slide carousel={5} slideNum={4} total={C5_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Blocks are visible</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>Ranked, with reasons in plain sight.</h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {cands.map((c) => (
            <div key={c.rank} className="dt-panel" style={{ padding: "22px 28px", display: "flex", alignItems: "center", gap: 22 }}>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 28, color: "var(--rust)", width: 56 }}>#{c.rank}</span>
              <span className="dt-h3" style={{ fontSize: 28, flex: "0 0 280px" }}>{c.name}</span>
              <span className="dt-body-text" style={{ flex: 1, fontSize: 20 }}>{c.note}</span>
              <Tag tone={c.tone}>{c.tone.toUpperCase()}</Tag>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C5S5() {
  return (
    <Slide carousel={5} slideNum={5} total={C5_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Warnings are visible</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 80 }}>
          Not buried in a tooltip.<br/>
          Not hidden behind a score.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 36, borderLeft: "3px solid var(--warn)", maxWidth: 820 }}>
          <Tag tone="warn">WARNING · FATIGUE</Tag>
          <div className="dt-h3" style={{ marginTop: 20, fontSize: 30 }}>B. Tahi · 11.2 hrs yesterday · 14 hrs day before</div>
          <div className="dt-body-text" style={{ marginTop: 12, fontSize: 20 }}>
            Within hard-block threshold. Override allowed with a reason. Override is recorded against this allocation.
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C5S6() {
  return (
    <Slide carousel={5} slideNum={6} total={C5_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Reasons are visible</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Every line on the list<br/>can be <span className="dt-rust">expanded.</span>
        </h2>
        <div className="dt-panel" style={{ padding: 0, maxWidth: 900 }}>
          <div style={{ padding: "22px 28px", borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span style={{ fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 20 }}>#1 · L. Henderson</span>
            <Tag tone="ok">CLEAR</Tag>
          </div>
          <div style={{ padding: "26px 28px" }}>
            {[
              ["Role match", "Rigger · Dogger · matches J-2407"],
              ["HRWL", "Valid to 2027-04-12"],
              ["WAH", "Valid to 2026-11-30"],
              ["Fatigue", "8 hrs yesterday · 9 day before"],
              ["Schedule", "No conflicts in window"],
              ["Preference", "Civil sites · matches job type"]
            ].map(([k, v], i) => (
              <div key={i} style={{ display: "flex", padding: "10px 0", borderBottom: i < 5 ? "1px dashed var(--hairline)" : "none" }}>
                <span style={{ width: 220, fontFamily: "var(--font-mono)", fontSize: 15, letterSpacing: "0.08em", color: "var(--steel)", textTransform: "uppercase" }}>{k}</span>
                <span style={{ color: "var(--cream)", fontSize: 19 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C5S7() {
  return (
    <Slide carousel={5} slideNum={7} total={C5_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The decision</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 84 }}>
          The dispatcher<br/><span className="dt-rust">decides what to do next.</span>
        </h2>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 720, fontSize: 26 }}>
          SmartRank does not allocate. It shows the candidates, the blocks, the warnings, and the reasons — so the person on the desk has something to work from.
        </p>
        <Boundary>No autonomous dispatch. No score-only confirmation. No black box.</Boundary>
      </div>
    </Slide>
  );
}

function C5S8() {
  return (
    <Slide carousel={5} slideNum={8} total={C5_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">See SmartRank<br/>on a <span className="dt-rust">real allocation.</span></h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          We can walk one job through the SmartRank panel — every signal, every flag, every override path — so you can see exactly what your dispatcher would be deciding from.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Walk through SmartRank" />
        </div>
      </div>
    </Slide>
  );
}

window.C5 = { slides: [C5S1, C5S2, C5S3, C5S4, C5S5, C5S6, C5S7, C5S8], title: "SmartRank Is Not Magic AI", id: "carousel-05-smartrank" };
