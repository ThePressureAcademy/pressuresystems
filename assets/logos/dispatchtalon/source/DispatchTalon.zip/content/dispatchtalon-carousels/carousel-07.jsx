/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock */
// Carousel 7 — Plant Numbers Matter

const C7_TOTAL = 8;

function C7S1() {
  return (
    <Slide carousel={7} slideNum={1} total={C7_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>07 · Plant numbers</Eyebrow>
        <h1 className="dt-display lg">
          A job does not<br/>always need<br/><span className="dt-rust">"a crane."</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          Sometimes it needs a specific plant item, in a specific configuration, with a specific transport profile.
        </p>
      </div>
    </Slide>
  );
}

function C7S2() {
  return (
    <Slide carousel={7} slideNum={2} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The class</Eyebrow>
        <h2 className="dt-display md">
          <span className="dt-rust">20T Mobile Crane</span><br/>is the <span className="dt-steel">class.</span>
        </h2>
        <div className="dt-panel" style={{ marginTop: 64, padding: 36, maxWidth: 820, textAlign: "left" }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)" }}>EQUIPMENT CATALOGUE</div>
          <div className="dt-h2" style={{ fontSize: 46, marginTop: 14 }}>20T Mobile Crane</div>
          <div className="dt-body-text" style={{ marginTop: 14, fontSize: 22 }}>
            Generic capability. A category of asset your business owns or hires. Not a specific machine.
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C7S3() {
  return (
    <Slide carousel={7} slideNum={3} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The asset</Eyebrow>
        <h2 className="dt-display md">
          <span className="dt-rust">MC20-001</span><br/>is the <span className="dt-steel">actual asset.</span>
        </h2>
        <div className="dt-panel" style={{ marginTop: 64, padding: 36, maxWidth: 820, textAlign: "left", borderColor: "rgba(226,113,42,0.45)" }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--rust)" }}>ASSET REGISTER · MC20-001</div>
          <div className="dt-h2" style={{ fontSize: 46, marginTop: 14 }}>20T Mobile Crane <span className="dt-steel">/</span> MC20-001</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginTop: 22, fontFamily: "var(--font-mono)", fontSize: 17 }}>
            <span className="dt-steel">REG · 4-D-Q-1147</span>
            <span className="dt-cream">SERVICE · current</span>
            <span className="dt-steel">SERVICE DUE · 2026-07-04</span>
            <span className="dt-cream">CONFIG · standard cwt</span>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C7S4() {
  return (
    <Slide carousel={7} slideNum={4} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The distinction</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          DispatchTalon separates<br/>
          <span className="dt-rust">class</span> from <span className="dt-rust">plant number.</span>
        </h2>
        <div className="dt-twocol" style={{ maxWidth: 880 }}>
          <div className="dt-col">
            <div className="colhead">CLASS</div>
            <div className="dt-h3" style={{ fontSize: 30 }}>20T Mobile Crane</div>
            <div className="dt-body-text" style={{ fontSize: 18 }}>What the job needs.</div>
          </div>
          <div className="dt-col rust">
            <div className="colhead">PLANT NUMBER</div>
            <div className="dt-h3" style={{ fontSize: 30 }}>MC20-001</div>
            <div className="dt-body-text" style={{ fontSize: 18 }}>What gets dispatched.</div>
          </div>
        </div>
        <Boundary>The job carries both. The audit trail keeps the link.</Boundary>
      </div>
    </Slide>
  );
}

function C7S5() {
  return (
    <Slide carousel={7} slideNum={5} total={C7_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Multiple assets, one class</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Multiple assets can sit<br/>under the <span className="dt-rust">same class.</span>
        </h2>
        <div className="dt-panel inset" style={{ padding: 0 }}>
          <div style={{ padding: "22px 32px", borderBottom: "1px solid var(--hairline)" }}>
            <span className="dt-mono" style={{ color: "var(--steel)", fontSize: 14, letterSpacing: "0.12em" }}>CLASS</span>
            <div className="dt-h3" style={{ fontSize: 28, marginTop: 6 }}>20T Mobile Crane</div>
          </div>
          {[
            ["MC20-001", "current · standard cwt", "available"],
            ["MC20-002", "current · extra cwt fitted", "on Goodna job"],
            ["MC20-003", "service due · in yard", "available"]
          ].map(([id, cfg, st], i) => (
            <div key={i} style={{ padding: "20px 32px", display: "flex", alignItems: "center", gap: 24, borderBottom: i < 2 ? "1px dashed var(--hairline)" : "none" }}>
              <span style={{ fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 22, flex: "0 0 180px" }}>{id}</span>
              <span className="dt-body-text" style={{ fontSize: 19, flex: 1 }}>{cfg}</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, letterSpacing: "0.08em", color: "var(--steel)", textTransform: "uppercase" }}>{st}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C7S6() {
  return (
    <Slide carousel={7} slideNum={6} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>On the job</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 74 }}>
          The job carries the<br/><span className="dt-rust">requirement</span> and the<br/><span className="dt-rust">selected asset.</span>
        </h2>
        <div className="dt-panel framed" style={{ marginTop: 56, padding: 32, maxWidth: 880, textAlign: "left" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
            <span className="dt-mono" style={{ letterSpacing: "0.12em", color: "var(--steel)" }}>JOB · J-2407 · IPSWICH</span>
            <Tag tone="rust">PLANT + LABOUR</Tag>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div>
              <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--steel)" }}>REQUIREMENT</div>
              <div className="dt-h3" style={{ fontSize: 28, marginTop: 6 }}>20T Mobile Crane</div>
            </div>
            <div>
              <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--rust)" }}>SELECTED</div>
              <div className="dt-h3" style={{ fontSize: 28, marginTop: 6 }}>MC20-002</div>
            </div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C7S7() {
  return (
    <Slide carousel={7} slideNum={7} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The outcome</Eyebrow>
        <div className="dt-quote">
          <span className="mark">"</span>That is<br/>
          <span className="dt-rust">allocation clarity.</span>
        </div>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 720, fontSize: 26 }}>
          Not just "a crane went". A specific machine, with its configuration, attached to a specific job, with the trail intact.
        </p>
      </div>
    </Slide>
  );
}

function C7S8() {
  return (
    <Slide carousel={7} slideNum={8} total={C7_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">See the <span className="dt-rust">asset register</span><br/>on a plant + labour job.</h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          We'll show the class / plant-number split on a real job, and how DispatchTalon keeps both visible without forcing your dispatcher to retype anything.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Send context first" />
        </div>
      </div>
    </Slide>
  );
}

window.C7 = { slides: [C7S1, C7S2, C7S3, C7S4, C7S5, C7S6, C7S7, C7S8], title: "Plant Numbers Matter", id: "carousel-07-plant-numbers" };
