/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock */
// Carousel 8 — Counterweight and Transport Assumptions

const C8_TOTAL = 8;

function C8S1() {
  return (
    <Slide carousel={8} slideNum={1} total={C8_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>08 · Crane review</Eyebrow>
        <h1 className="dt-display lg">
          Counterweight<br/>assumptions should<br/>not live in <span className="dt-rust">someone's head.</span>
        </h1>
      </div>
    </Slide>
  );
}

function C8S2() {
  return (
    <Slide carousel={8} slideNum={2} total={C8_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What "100T" doesn't tell you</Eyebrow>
        <h2 className="dt-display md">
          Crane class is only<br/><span className="dt-rust">part of the picture.</span>
        </h2>
        <div style={{ marginTop: 64, display: "flex", flexDirection: "column", gap: 14, maxWidth: 760 }}>
          {[
            ["What you say", "100T Mobile Crane"],
            ["What's missing", "Travel state · counterweight gap · escorts"],
            ["Where it lives", "Yard whiteboard · last week's job · memory"]
          ].map(([k, v], i) => (
            <div key={i} className="dt-panel" style={{ padding: "20px 28px", display: "flex", gap: 28, alignItems: "center" }}>
              <span style={{ flex: "0 0 220px", fontFamily: "var(--font-mono)", fontSize: 14, letterSpacing: "0.1em", color: "var(--steel)", textTransform: "uppercase" }}>{k}</span>
              <span className="dt-h3" style={{ fontSize: 24, color: i === 2 ? "var(--cream-dim)" : "var(--cream)" }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C8S3() {
  const items = [
    ["Travel state", "Self-propelled · towed · disassembled"],
    ["Counterweight gap", "Required vs available on site"],
    ["Support transport", "Escort · pilot · float"],
    ["Road-access review", "NHVR prompt · permit dependency"]
  ];
  return (
    <Slide carousel={8} slideNum={3} total={C8_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What gets surfaced</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>Four review surfaces. One panel.</h2>
        <div className="dt-panel inset" style={{ padding: 0 }}>
          {items.map(([k, v], i) => (
            <div key={i} style={{ padding: "24px 32px", borderBottom: i < items.length - 1 ? "1px solid var(--hairline)" : "none", display: "flex", alignItems: "center", gap: 22 }}>
              <span style={{ flex: "0 0 60px", fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 18 }}>0{i + 1}</span>
              <span style={{ flex: "0 0 320px", fontFamily: "var(--font-mono)", fontSize: 16, letterSpacing: "0.08em", color: "var(--cream)", textTransform: "uppercase" }}>{k}</span>
              <span style={{ color: "var(--cream-dim)", fontSize: 22 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C8S4() {
  return (
    <Slide carousel={8} slideNum={4} total={C8_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Where the flags appear</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Review flags surface<br/><span className="dt-rust">before dispatch.</span>
        </h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="dt-panel" style={{ padding: 28, borderLeft: "3px solid var(--rust)" }}>
            <Tag tone="rust">REVIEW · COUNTERWEIGHT</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 28 }}>MC100-002 · standard cwt fitted · site requires +6m gap</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 18 }}>Human confirmation required before allocation.</div>
          </div>
          <div className="dt-panel" style={{ padding: 28, borderLeft: "3px solid var(--rust)" }}>
            <Tag tone="rust">REVIEW · TRANSPORT</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 28 }}>Travel state self-propelled · support escort not assigned</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 18 }}>Suggested for review based on travel mode.</div>
          </div>
          <div className="dt-panel" style={{ padding: 28, borderLeft: "3px solid var(--rust)" }}>
            <Tag tone="rust">REVIEW · ROAD ACCESS</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 28 }}>Route crosses NHVR-regulated corridor · prompt only</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 18 }}>Dispatcher confirms permit / route status outside the system.</div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C8S5() {
  return (
    <Slide carousel={8} slideNum={5} total={C8_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Boundary</Eyebrow>
        <h2 className="dt-display md">
          It does <span className="dt-rust">not</span><br/>approve permits.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 36, maxWidth: 820, textAlign: "left" }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)" }}>NOT A PERMIT SYSTEM</div>
          <div className="dt-h3" style={{ marginTop: 14, fontSize: 30 }}>
            DispatchTalon does not lodge, automate, or approve NHVR / road-access / load-rating permits.
          </div>
          <div className="dt-body-text" style={{ marginTop: 14, fontSize: 20 }}>
            It prompts your dispatcher to confirm them before allocation, and records the response in the audit trail.
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C8S6() {
  return (
    <Slide carousel={8} slideNum={6} total={C8_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Boundary</Eyebrow>
        <h2 className="dt-display md">
          It does <span className="dt-rust">not</span><br/>engineer lifts.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 36, maxWidth: 820, textAlign: "left" }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)" }}>NOT A LIFT STUDY</div>
          <div className="dt-h3" style={{ marginTop: 14, fontSize: 30 }}>
            DispatchTalon does not calculate load charts, radius safe-working-load, or counterweight ratings.
          </div>
          <div className="dt-body-text" style={{ marginTop: 14, fontSize: 20 }}>
            The engineering sits with your lift planner and crew. The system creates a review point so the conversation happens before dispatch — not after.
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C8S7() {
  return (
    <Slide carousel={8} slideNum={7} total={C8_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What it does do</Eyebrow>
        <div className="dt-quote">
          <span className="mark">"</span>It creates a<br/>
          <span className="dt-rust">structured review point.</span>
        </div>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 720, fontSize: 26 }}>
          The counterweight question stops being a phone call you might miss. It becomes a flag that sits on the allocation panel until someone resolves it.
        </p>
        <Boundary>Pilot-stage workflow. Dispatcher-led. No compliance guarantee.</Boundary>
      </div>
    </Slide>
  );
}

function C8S8() {
  return (
    <Slide carousel={8} slideNum={8} total={C8_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">See the <span className="dt-rust">crane review</span><br/>panel on a real job.</h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          We can show how counterweight, transport, and road-access flags appear in DispatchTalon — and where the dispatcher remains the one who confirms.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Send context first" />
        </div>
      </div>
    </Slide>
  );
}

window.C8 = { slides: [C8S1, C8S2, C8S3, C8S4, C8S5, C8S6, C8S7, C8S8], title: "Counterweight and Transport Assumptions", id: "carousel-08-counterweight-transport" };
