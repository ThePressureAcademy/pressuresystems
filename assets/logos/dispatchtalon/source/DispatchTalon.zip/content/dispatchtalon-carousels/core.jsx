/* global React */
const { useState } = React;

// ---------- DispatchTalon mark — LOCKED brand asset ----------
// Uses the real header-mark PNG from the Pressure Systems brand kit.
// Path is repo-relative so it works whether index.html lives at root
// or inside a sub-folder.
const TALON_MARK_SRC = "assets/logos/dispatchtalon/dispatchtalon-header-mark-transparent.png";
const TALON_LOCKUP_SRC = "assets/logos/dispatchtalon/dispatchtalon-header-lockup-transparent.png";
const TALON_PRIMARY_LOCKUP_SRC = "assets/logos/dispatchtalon/dispatchtalon-primary-lockup.png";

function TalonMark({ size = 44, className = "" }) {
  return (
    <img
      src={TALON_MARK_SRC}
      width={size}
      height={size}
      alt="DispatchTalon mark"
      className={className}
      style={{ display: "block", objectFit: "contain" }}
      draggable={false}
    />
  );
}

// ---------- Slide shell ----------
function Slide({ carousel, slideNum, total, children, label = "DispatchTalon", showHead = true, showFoot = true, bigMark = false }) {
  return (
    <div className="dt-slide" data-screen-label={`C${carousel} S${slideNum}`}>
      {bigMark && <TalonMark size={720} className="dt-mark huge" />}
      <TalonMark size={64} className="dt-mark" />
      {showHead && (
        <div className="dt-head">
          <span><span className="dot" />{label}</span>
        </div>
      )}
      {children}
      {showFoot && (
        <div className="dt-foot">
          <span>
            DispatchTalon <strong>by Pressure Systems</strong>
            <span className="dt-num" style={{ marginLeft: 18, color: "var(--steel-soft)" }}>
              · {String(slideNum).padStart(2,"0")} / {String(total).padStart(2,"0")}
            </span>
          </span>
          <span>Pilot-stage workflow · Dispatcher-led review</span>
        </div>
      )}
    </div>
  );
}

// ---------- Small re-usable bits used across carousels ----------
function Tag({ tone, children }) {
  const cls = ["dt-tag"];
  if (tone) cls.push(tone);
  return <span className={cls.join(" ")}>{children}</span>;
}

function Node({ size = "md", label = "Decision", children }) {
  const cls = ["dt-node"];
  if (size === "sm") cls.push("sm");
  if (size === "xs") cls.push("xs");
  return <div className={cls.join(" ")}>{children ?? label}</div>;
}

function Trail({ on = 3, total = 7 }) {
  return (
    <div className="dt-trail">
      {Array.from({ length: total }).map((_, i) => (
        <span key={i} className={"pip" + (i < on ? " on" : "")} />
      ))}
    </div>
  );
}

function Eyebrow({ children }) {
  return <div className="dt-eyebrow">{children}</div>;
}

function Boundary({ children }) {
  return <div className="dt-boundary">{children}</div>;
}

function CtaBlock({ primary = "Book a discovery call", secondary = "Watch the portal walkthrough" }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16, marginTop: 16 }}>
      <div className="dt-cta">
        <span>{primary}</span>
        <span className="arrow">→</span>
      </div>
      <div className="dt-cta ghost">
        <span>{secondary}</span>
        <span className="arrow">→</span>
      </div>
    </div>
  );
}

// Audit ticker stub
function Ticker({ rows }) {
  return (
    <div className="dt-ticker">
      {rows.map((r, i) => (
        <div className="row" key={i}>
          <span className="ts">{r[0]}</span>
          <span className={"ev" + (r[2] ? " rust" : "")}>{r[1]}</span>
        </div>
      ))}
    </div>
  );
}

// Primary horizontal lockup — for cover / strategy / proposal-style surfaces
function TalonLockup({ height = 120, variant = "header", className = "" }) {
  const src = variant === "primary" ? TALON_PRIMARY_LOCKUP_SRC : TALON_LOCKUP_SRC;
  return (
    <img
      src={src}
      alt="DispatchTalon by Pressure Systems"
      style={{ height, width: "auto", display: "block", objectFit: "contain" }}
      className={className}
      draggable={false}
    />
  );
}

Object.assign(window, { Slide, TalonMark, TalonLockup, Tag, Node, Trail, Eyebrow, Boundary, CtaBlock, Ticker, TALON_MARK_SRC, TALON_LOCKUP_SRC, TALON_PRIMARY_LOCKUP_SRC });
