# DispatchTalon · LinkedIn carousel system

Open **`DispatchTalon Carousels.html`** to view everything on one zoomable canvas.

## What's in this build

- **8 LinkedIn carousels** (64 slides total, 1080×1350 each)
  - 01 — Rough Job Notes Become Dispatch Risk (Job Brief Import)
  - 02 — The Dispatcher Still Decides (Boundary)
  - 03 — Labour-Only vs Plant + Labour (Modes)
  - 04 — Why Allocation Decisions Need a Trail (Audit)
  - 05 — SmartRank Is Not Magic AI (Explainable rank)
  - 06 — Build My Business (Onboarding)
  - 07 — Plant Numbers Matter (Asset register)
  - 08 — Counterweight and Transport Assumptions (Crane review)
- **Strategy pack** at the bottom of the canvas
  - Master carousel strategy + priority order
  - Design-system card (palette, type, motifs)
  - Claim-boundary checklist (allowed vs forbidden language)
  - Designer production checklist
  - Crop & reuse guidance (square / IG / web / email / PDF / investor)
  - Short-form cutdown ideas (8–15s reels)
  - Outstanding-asset / screenshot gap list
  - LinkedIn captions (one per carousel)
  - CTA bank

## How to use the canvas

- Drag empty space to pan, scroll to zoom
- Click any slide's expand icon to view it 1:1 (←/→/Esc to navigate)
- Drag the grip on a slide to reorder; click the title to rename
- Slide artboards are exactly 1080×1350, so the focus view = export PNG

## File map

```
DispatchTalon Carousels.html         entry point
content/dispatchtalon-carousels/
  styles.css                         tokens + slide chrome
  core.jsx                           Slide shell, TalonMark, motifs
  design-canvas.jsx                  pan/zoom canvas (starter)
  carousel-01.jsx … carousel-08.jsx  the 8 carousels
  strategy.jsx                       captions, CTA bank, QA docs
  app.jsx                            wires it all into the canvas
```

## Design system, at a glance

- **Charcoal `#0E1216`** background · **Cream `#F2F0E6`** headlines · **Steel `#6B7077`** support · **Rust `#E2712A`** reserved for the decision-node, primary CTA, and rust-tagged review surface
- **Space Grotesk** display + body, **IBM Plex Mono** operational labels
- Watermark: original geometric **Talon mark** (chevron-into-point inside a containment square), placed corner-small or as a faint background device on slide 1
- Motif kit: decision node (rust circle with aura), dispatch path line, audit trail dots, block/warn/review tags, before/after columns, vertical decision chain

## Claim-boundary discipline

Every slide passes the checklist on `Claim boundaries`:

- ✓ "Structures the decision before dispatch"
- ✓ "Dispatcher remains the decision-maker"
- ✓ "Records override reasons"
- ✓ "Pilot-stage workflow · managed pilot"
- ✗ No "safe to dispatch", "compliance approved", "permit ready"
- ✗ No autonomous-dispatch language
- ✗ No "AI-powered everything", "revolutionary", "game-changing"
- ✗ No old LIFTIQ or claw-style marks

## What still needs real screenshots

See **Asset gaps** in the strategy section. Until pilot screenshots are dropped in, layouts use pilot-realistic mock data (not aspirational). The candidates to replace first:

1. C5 slide 4 — SmartRank candidate list
2. C4 slide 4 — audit ticker export
3. C8 slides 4–6 — crane review panel
4. C1 slide 6 — Job Brief Import field grid

## Recommended posting order

For cold LinkedIn traffic:

1. **C2** — Dispatcher still decides (defuses AI scepticism)
2. **C1** — Rough notes become dispatch risk (concrete pain)
3. **C4** — Audit trail (commercial buyer hook)
4. C5 — SmartRank
5. C7 — Plant numbers
6. C8 — Counterweight + transport
7. C3 — Operating modes
8. C6 — Build My Business (warm / retargeting)

## Export

Each slide artboard renders at exactly 1080×1350 in focus mode. To produce shipping PNGs, screenshot each artboard in focus view (or wire the design canvas's slot DOM into your existing exporter). Strategy artboards are wider (1200×variable) — those are reference docs, not for publication.
