/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock */
// Carousel 3 — Labour-Only vs Plant + Labour

const C3_TOTAL = 8;

function C3S1() {
  return (
    <Slide carousel={3} slideNum={1} total={C3_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>03 · Operating modes</Eyebrow>
        <h1 className="dt-display lg">
          Not every operation<br/>needs the same<br/><span className="dt-rust">dispatch screen.</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          DispatchTalon ships in two modes. A labour-only crew should not stare at plant fields. A plant + labour business should not lose them.
        </p>
      </div>
    </Slide>
  );
}

function C3S2() {
  return (
    <Slide carousel={3} slideNum={2} total={C3_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Mode 01</Eyebrow>
        <h2 className="dt-display md">
          <span className="dt-rust">Labour-only.</span><br/>
          Focused on people.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 0, maxWidth: 880 }}>
          <div style={{ padding: "26px 32px", borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span className="dt-mono" style={{ letterSpacing: "0.12em" }}>JOB · ROOF SAFETY · BRISBANE NORTH</span>
            <Tag tone="rust">LABOUR-ONLY</Tag>
          </div>
          <div style={{ padding: "28px 32px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {[
              ["Worker", "L. Henderson"],
              ["Role", "Rigger / Dogger"],
              ["Credentials", "HRWL · WAH · EWP"],
              ["Fatigue", "Within window"],
              ["Schedule", "Thu 0700 – 1500"],
              ["Preference", "Civil sites"]
            ].map(([k, v], i) => (
              <div key={i}>
                <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--steel)" }}>{k}</div>
                <div className="dt-body-text" style={{ color: "var(--cream)", fontSize: 22, marginTop: 4 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C3S3() {
  const fields = ["Workers", "Roles", "Credentials", "VOCs", "Fatigue", "Schedule", "SmartRank", "Audit"];
  return (
    <Slide carousel={3} slideNum={3} total={C3_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Labour-only · what you see</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 56 }}>People-first. Nothing else in the way.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          {fields.map((f, i) => (
            <div key={i} className="dt-panel" style={{ padding: "28px 32px", display: "flex", alignItems: "center", gap: 20 }}>
              <span className="dt-mono" style={{ color: "var(--rust)", fontSize: 18 }}>0{i + 1}</span>
              <span className="dt-h3" style={{ fontSize: 28 }}>{f}</span>
            </div>
          ))}
        </div>
        <Boundary>No equipment catalogue. No plant fields. Less noise on the desk.</Boundary>
      </div>
    </Slide>
  );
}

function C3S4() {
  return (
    <Slide carousel={3} slideNum={4} total={C3_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Mode 02</Eyebrow>
        <h2 className="dt-display md">
          <span className="dt-rust">Plant + labour.</span><br/>
          Opens the equipment layer.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 0, maxWidth: 920 }}>
          <div style={{ padding: "26px 32px", borderBottom: "1px solid var(--hairline)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <span className="dt-mono" style={{ letterSpacing: "0.12em" }}>JOB · 100T LIFT · IPSWICH</span>
            <Tag tone="rust">PLANT + LABOUR</Tag>
          </div>
          <div style={{ padding: "28px 32px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {[
              ["Asset class", "100T Mobile Crane"],
              ["Plant number", "MC100-002"],
              ["Travel state", "Self-propelled"],
              ["Counterweight", "Review flag"],
              ["Support transport", "Pilot · escort"],
              ["Crew", "2× Rigger · 1× Dogger"]
            ].map(([k, v], i) => (
              <div key={i}>
                <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.12em", color: "var(--steel)" }}>{k}</div>
                <div className="dt-body-text" style={{ color: "var(--cream)", fontSize: 22, marginTop: 4 }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C3S5() {
  const items = ["Asset classes", "Plant numbers", "Crane model & travel state", "Counterweight review", "Support transport", "Road-access prompts", "Job readiness", "Audit"];
  return (
    <Slide carousel={3} slideNum={5} total={C3_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Plant + labour · what's added</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 56 }}>Everything in labour-only, plus the equipment context.</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
          {items.map((f, i) => (
            <div key={i} className="dt-panel" style={{ padding: "22px 28px", display: "flex", alignItems: "center", gap: 20, borderColor: "rgba(226,113,42,0.3)" }}>
              <span className="dt-mono" style={{ color: "var(--rust)", fontSize: 18 }}>+</span>
              <span className="dt-h3" style={{ fontSize: 26 }}>{f}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C3S6() {
  return (
    <Slide carousel={3} slideNum={6} total={C3_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Setup choice</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 80 }}>
          Build the portal<br/>around <span className="dt-rust">how your business</span><br/>actually works.
        </h2>
        <div className="dt-twocol" style={{ marginTop: 80, maxWidth: 880 }}>
          <div className="dt-col" style={{ alignItems: "flex-start" }}>
            <div className="colhead">If you allocate people</div>
            <div className="dt-h3" style={{ fontSize: 32 }}>Labour-only</div>
            <div className="dt-body-text" style={{ fontSize: 20 }}>Workers, roles, credentials, fatigue.</div>
          </div>
          <div className="dt-col rust" style={{ alignItems: "flex-start" }}>
            <div className="colhead">If you allocate plant too</div>
            <div className="dt-h3" style={{ fontSize: 32 }}>Plant + labour</div>
            <div className="dt-body-text" style={{ fontSize: 20 }}>Equipment, plant numbers, transport.</div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C3S7() {
  return (
    <Slide carousel={3} slideNum={7} total={C3_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What you skip</Eyebrow>
        <h2 className="dt-display md">
          No bloated<br/><span className="dt-steel">generic setup.</span>
        </h2>
        <div style={{ marginTop: 56, display: "flex", flexDirection: "column", gap: 16, maxWidth: 760 }}>
          {[
            "No empty plant fields on labour jobs",
            "No worker imports forced before you've picked a mode",
            "No catalogue clutter from features you do not use",
            "No \"all-in-one\" dispatch screen that fits nobody"
          ].map((t, i) => (
            <div key={i} style={{ display: "flex", gap: 18, alignItems: "center" }}>
              <span style={{ color: "var(--rust)", fontFamily: "var(--font-mono)" }}>—</span>
              <span className="dt-body-text" style={{ fontSize: 24, color: "var(--cream)" }}>{t}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C3S8() {
  return (
    <Slide carousel={3} slideNum={8} total={C3_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">Pick the mode<br/>that <span className="dt-rust">fits your business.</span></h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          We'll walk you through the labour-only and plant + labour setup, side by side, so you can see which one matches your dispatch reality.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="See how the modes differ" />
        </div>
      </div>
    </Slide>
  );
}

window.C3 = { slides: [C3S1, C3S2, C3S3, C3S4, C3S5, C3S6, C3S7, C3S8], title: "Labour-Only vs Plant + Labour", id: "carousel-03-operating-modes" };
