/* global React, Slide, Tag, Node, Eyebrow, Boundary, CtaBlock, Ticker */
// Carousel 1 — Rough Job Notes Become Dispatch Risk (Job Brief Import)

const C1_TOTAL = 8;

function C1S1() {
  return (
    <Slide carousel={1} slideNum={1} total={C1_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>01 · Job intake</Eyebrow>
        <h1 className="dt-display lg">
          Rough job notes<br/>should not become<br/><span className="dt-rust">dispatch risk.</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          The job starts the moment a phone rings. Most allocation problems start there too — long before anyone walks on site.
        </p>
      </div>
    </Slide>
  );
}

function C1S2() {
  const channels = [
    { src: "Phone call · 06:42", body: "Need 2 riggers + dogger Thursday 7am. Maybe 80T. Talk to Macca." },
    { src: "SMS · 07:08", body: "actually make it 100T, counterweight tight on site" },
    { src: "Email · 07:55", body: "Permit copy attached. Crew to arrive 0630 not 0700." },
    { src: "Whiteboard note", body: "MC100 might be on Goodna job? check with yard" }
  ];
  return (
    <Slide carousel={1} slideNum={2} total={C1_TOTAL}>
      <div className="dt-body">
        <Eyebrow>How a job actually arrives</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Job details arrive messy.<br/>
          <span className="dt-steel">Calls, texts, emails, notes.</span>
        </h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {channels.map((c, i) => (
            <div className="dt-panel" key={i} style={{ padding: "22px 28px" }}>
              <div className="lbl" style={{ marginBottom: 6 }}>{c.src}</div>
              <div className="dt-body-text" style={{ color: "var(--cream)" }}>{c.body}</div>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C1S3() {
  return (
    <Slide carousel={1} slideNum={3} total={C1_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The real risk</Eyebrow>
        <h2 className="dt-display md">
          The risk is not the note.<br/>
          It is <span className="dt-rust">what gets missed</span> after it.
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18, marginTop: 56, maxWidth: 880 }}>
          {[
            "Counterweight gap not raised before dispatch",
            "VOC expiry missed under pressure",
            "Travel state not checked against route",
            "Second job already scheduled for that operator",
            "One-off site condition lost in the inbox",
            "Crew arrival time updated only in one channel"
          ].map((t, i) => (
            <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
              <span style={{ color: "var(--rust)", fontFamily: "var(--font-mono)", fontSize: 18, marginTop: 4 }}>—</span>
              <span className="dt-body-text">{t}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C1S4() {
  return (
    <Slide carousel={1} slideNum={4} total={C1_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What DispatchTalon does</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 48 }}>
          Rough details become<br/><span className="dt-rust">structured job requirements.</span>
        </h2>
        <div className="dt-twocol">
          <div className="dt-col">
            <div className="colhead">Pasted text · 0742</div>
            <div className="dt-body-text" style={{ fontSize: 19, lineHeight: 1.4 }}>
              "Need 2 riggers + dogger Thurs 7am, 100T mob crane, counterweight tight, permit attached, crew 0630"
            </div>
          </div>
          <div className="dt-col rust">
            <div className="colhead">Suggested fields</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, fontFamily: "var(--font-mono)", fontSize: 16 }}>
              <div><span className="dt-steel">role · </span><span className="dt-cream">2× Rigger, 1× Dogger</span></div>
              <div><span className="dt-steel">date · </span><span className="dt-cream">Thu, 0630 start</span></div>
              <div><span className="dt-steel">class · </span><span className="dt-cream">100T Mobile Crane</span></div>
              <div><span className="dt-steel">flag  · </span><span className="dt-rust">Counterweight review</span></div>
              <div><span className="dt-steel">flag  · </span><span className="dt-rust">Site access (permit)</span></div>
            </div>
          </div>
        </div>
        <Boundary>
          Suggested. Not auto-confirmed. The dispatcher reviews every field before the job exists.
        </Boundary>
      </div>
    </Slide>
  );
}

function C1S5() {
  return (
    <Slide carousel={1} slideNum={5} total={C1_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Review before dispatch</Eyebrow>
        <h2 className="dt-display md">
          The dispatcher reviews<br/>before anything is<br/><span className="dt-rust">confirmed.</span>
        </h2>
        <div className="dt-chain" style={{ marginTop: 64, maxWidth: 700 }}>
          {[
            ["Brief imported", false],
            ["Fields suggested", false],
            ["Dispatcher review", true],
            ["Job created", false],
            ["Audit recorded", false]
          ].map(([t, on], i) => (
            <div className={"step" + (on ? " on" : "")} key={i}>
              <span className="bullet" />
              <span className="dt-h3" style={{ fontSize: 30, color: on ? "var(--cream)" : "var(--cream-dim)" }}>{t}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C1S6() {
  const fields = [
    ["JOB ROLES", "Rigger, Dogger, Crane Operator"],
    ["CREDENTIALS", "HRWL, Working at Heights, EWP"],
    ["SCHEDULE", "Thu 16 May · 0630 – 1500 · AEST"],
    ["TRAVEL", "127 km · over 100km flag"],
    ["SITE CONDITIONS", "Tight access · live road"],
    ["NOTES", "Counterweight 6m gap · check"]
  ];
  return (
    <Slide carousel={1} slideNum={6} total={C1_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What gets captured</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 36 }}>One job. Every field in one place.</h2>
        <div className="dt-panel framed" style={{ padding: 0 }}>
          {fields.map(([k, v], i) => (
            <div key={i} className="dt-row" style={{ padding: "22px 32px" }}>
              <span className="k">{String(i + 1).padStart(2, "0")}</span>
              <span style={{ flex: "0 0 280px", color: "var(--steel)", fontFamily: "var(--font-mono)", fontSize: 16, letterSpacing: "0.08em" }}>{k}</span>
              <span style={{ color: "var(--cream)", fontSize: 22 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C1S7() {
  return (
    <Slide carousel={1} slideNum={7} total={C1_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The shift</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 84 }}>
          <span className="dt-steel">Less retyping.</span><br/>
          More <span className="dt-rust">review</span> before dispatch.
        </h2>
        <div style={{ display: "flex", gap: 40, marginTop: 80, fontFamily: "var(--font-mono)" }}>
          <div>
            <div style={{ fontSize: 14, letterSpacing: "0.16em", color: "var(--steel)", marginBottom: 8 }}>BEFORE</div>
            <div style={{ fontSize: 22, color: "var(--cream-dim)", lineHeight: 1.4 }}>4 channels<br/>3 retypes<br/>0 audit</div>
          </div>
          <div style={{ width: 1, background: "var(--hairline-strong)" }} />
          <div>
            <div style={{ fontSize: 14, letterSpacing: "0.16em", color: "var(--rust)", marginBottom: 8 }}>AFTER</div>
            <div style={{ fontSize: 22, color: "var(--cream)", lineHeight: 1.4 }}>1 import<br/>1 review<br/>1 trail</div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C1S8() {
  return (
    <Slide carousel={1} slideNum={8} total={C1_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">See how a rough note<br/>becomes a <span className="dt-rust">structured job.</span></h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          A 15-minute discovery call. We look at how jobs reach your dispatcher today, and where DispatchTalon would sit in your workflow.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Watch the portal walkthrough" />
        </div>
      </div>
    </Slide>
  );
}

window.C1 = { slides: [C1S1, C1S2, C1S3, C1S4, C1S5, C1S6, C1S7, C1S8], title: "Rough Job Notes Become Dispatch Risk", id: "carousel-01-job-intake" };
