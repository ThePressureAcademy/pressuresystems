/* global React, Slide, Tag, Node, Eyebrow, Boundary, CtaBlock */
// Carousel 2 — The Dispatcher Still Decides

const C2_TOTAL = 8;

function C2S1() {
  return (
    <Slide carousel={2} slideNum={1} total={C2_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>02 · Boundary</Eyebrow>
        <h1 className="dt-display lg">
          DispatchTalon<br/>does not replace<br/><span className="dt-rust">the dispatcher.</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          It structures the decision before dispatch. The judgement stays with the person on the desk.
        </p>
      </div>
    </Slide>
  );
}

function C2S2() {
  return (
    <Slide carousel={2} slideNum={2} total={C2_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What it is</Eyebrow>
        <h2 className="dt-display md">
          Decision support,<br/>not <span className="dt-steel">autonomous dispatch.</span>
        </h2>
        <div style={{ marginTop: 80, display: "flex", alignItems: "center", justifyContent: "center", gap: 48 }}>
          <div style={{ textAlign: "center" }}>
            <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.16em", marginBottom: 16 }}>SYSTEM</div>
            <div className="dt-h3" style={{ color: "var(--cream-dim)" }}>Structures.<br/>Shows.<br/>Records.</div>
          </div>
          <div style={{ height: 140, width: 1, background: "var(--hairline-strong)" }} />
          <div style={{ textAlign: "center" }}>
            <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.16em", marginBottom: 16, color: "var(--rust)" }}>DISPATCHER</div>
            <div className="dt-h3">Reviews.<br/>Decides.<br/>Confirms.</div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C2S3() {
  const signals = [
    ["WORKER FIT", "Role match · task preference"],
    ["CREDENTIALS", "Tickets, VOCs, expiry"],
    ["FATIGUE", "Hours worked · rest history"],
    ["SCHEDULE", "Conflicts · availability"],
    ["JOB REQUIREMENTS", "Roles · plant · conditions"]
  ];
  return (
    <Slide carousel={2} slideNum={3} total={C2_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What it shows</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>Five signals, in one panel.</h2>
        <div className="dt-panel inset" style={{ padding: 0 }}>
          {signals.map(([k, v], i) => (
            <div key={i} className="dt-row" style={{ padding: "26px 32px" }}>
              <span style={{ flex: "0 0 56px", fontFamily: "var(--font-mono)", color: "var(--rust)", fontSize: 18 }}>0{i+1}</span>
              <span style={{ flex: "0 0 320px", fontFamily: "var(--font-mono)", fontSize: 16, letterSpacing: "0.08em", color: "var(--steel)" }}>{k}</span>
              <span style={{ color: "var(--cream)", fontSize: 22 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C2S4() {
  return (
    <Slide carousel={2} slideNum={4} total={C2_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What it flags</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 48 }}>Blocks. Warnings. Reviews.</h2>
        <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
          <div className="dt-panel" style={{ borderLeft: "3px solid var(--block)" }}>
            <Tag tone="block">BLOCK</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 32 }}>HRWL ticket expired 3 days ago</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 20 }}>Worker cannot be allocated to this role.</div>
          </div>
          <div className="dt-panel" style={{ borderLeft: "3px solid var(--warn)" }}>
            <Tag tone="warn">WARNING</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 32 }}>Fatigue: 11 hrs yesterday, 14 the day before</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 20 }}>Override allowed with a reason.</div>
          </div>
          <div className="dt-panel" style={{ borderLeft: "3px solid var(--rust)" }}>
            <Tag tone="rust">REVIEW</Tag>
            <div className="dt-h3" style={{ marginTop: 16, fontSize: 32 }}>Counterweight gap flagged on this asset</div>
            <div className="dt-body-text" style={{ marginTop: 6, fontSize: 20 }}>Human confirmation required before allocation.</div>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C2S5() {
  return (
    <Slide carousel={2} slideNum={5} total={C2_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What it records</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Override reasons,<br/>captured in plain text.
        </h2>
        <div className="dt-panel inset framed" style={{ padding: 36 }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)" }}>
            ALLOCATION · J-2407 · CRANE OPERATOR
          </div>
          <div className="dt-h3" style={{ marginTop: 18, fontSize: 30 }}>Override: fatigue warning</div>
          <div style={{ marginTop: 28, padding: 22, background: "var(--charcoal)", border: "1px solid var(--hairline)", borderRadius: 4, fontFamily: "var(--font-mono)", fontSize: 17, color: "var(--cream-dim)", lineHeight: 1.5 }}>
            "Crew rotated home Friday. Worker confirmed full rest weekend. No third shift in seven-day window. Approved by Lead Dispatcher."
          </div>
          <div style={{ display: "flex", gap: 24, marginTop: 22, fontFamily: "var(--font-mono)", fontSize: 14, color: "var(--steel)" }}>
            <span>BY · L. Henderson</span>
            <span>AT · 2026-05-15 07:42 AEST</span>
            <span>EVENT · #ovr-44128</span>
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C2S6() {
  return (
    <Slide carousel={2} slideNum={6} total={C2_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The confirmation</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 88 }}>
          A human still confirms<br/>the allocation.
        </h2>
        <div style={{ marginTop: 80, display: "flex", justifyContent: "center", gap: 32, alignItems: "center" }}>
          <div className="dt-tag" style={{ height: 56, fontSize: 18, padding: "0 28px" }}>Ranked candidates</div>
          <span style={{ color: "var(--steel)", fontFamily: "var(--font-mono)" }}>→</span>
          <div className="dt-tag rust" style={{ height: 56, fontSize: 18, padding: "0 28px" }}>Confirm allocation</div>
          <span style={{ color: "var(--steel)", fontFamily: "var(--font-mono)" }}>→</span>
          <div className="dt-tag" style={{ height: 56, fontSize: 18, padding: "0 28px" }}>Audit recorded</div>
        </div>
        <p className="dt-lead" style={{ marginTop: 72, maxWidth: 720, fontSize: 26 }}>
          The system never sends the worker. The dispatcher does.
        </p>
      </div>
    </Slide>
  );
}

function C2S7() {
  return (
    <Slide carousel={2} slideNum={7} total={C2_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The point</Eyebrow>
        <div className="dt-quote">
          <span className="mark">"</span>Better clarity,<br/>not blind automation.
        </div>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 720, fontSize: 26 }}>
          You might already have a system. The question is whether it explains the decision before dispatch.
        </p>
      </div>
    </Slide>
  );
}

function C2S8() {
  return (
    <Slide carousel={2} slideNum={8} total={C2_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">Walk through the<br/><span className="dt-rust">review-before-dispatch</span> screen.</h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          We can show how worker fit, blocks, warnings, and override reasons sit in one panel — and where your dispatcher remains the decision-maker.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Watch the portal walkthrough" />
        </div>
      </div>
    </Slide>
  );
}

window.C2 = { slides: [C2S1, C2S2, C2S3, C2S4, C2S5, C2S6, C2S7, C2S8], title: "The Dispatcher Still Decides", id: "carousel-02-dispatcher-decides" };
