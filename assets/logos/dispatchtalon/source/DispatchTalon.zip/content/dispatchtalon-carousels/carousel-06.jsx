/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock */
// Carousel 6 — Build My Business (onboarding)

const C6_TOTAL = 8;

function StepCard({ n, title, body, tag }) {
  return (
    <div className="dt-panel" style={{ padding: "26px 30px", display: "flex", gap: 22, alignItems: "flex-start" }}>
      <div style={{ flex: "0 0 64px" }}>
        <div className="dt-node-out" style={{ width: 56, height: 56 }}>{n}</div>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span className="dt-h3" style={{ fontSize: 28 }}>{title}</span>
          {tag && <Tag tone="rust">{tag}</Tag>}
        </div>
        <div className="dt-body-text" style={{ fontSize: 19, marginTop: 8 }}>{body}</div>
      </div>
    </div>
  );
}

function C6S1() {
  return (
    <Slide carousel={6} slideNum={1} total={C6_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>06 · Build My Business</Eyebrow>
        <h1 className="dt-display lg">
          Start with a<br/><span className="dt-rust">clean system.</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          DispatchTalon opens with a first-run setup, not a 200-field empty database. You enable what your business actually uses — nothing more.
        </p>
      </div>
    </Slide>
  );
}

function C6S2() {
  return (
    <Slide carousel={6} slideNum={2} total={C6_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Step 01</Eyebrow>
        <h2 className="dt-display md">
          Choose <span className="dt-rust">Labour-only</span><br/>or <span className="dt-rust">Plant + labour.</span>
        </h2>
        <div className="dt-twocol" style={{ marginTop: 64, maxWidth: 880 }}>
          <div className="dt-col" style={{ padding: 32, gap: 8 }}>
            <div className="colhead">Mode A</div>
            <div className="dt-h3" style={{ fontSize: 30 }}>Labour-only</div>
            <div className="dt-body-text" style={{ fontSize: 18 }}>People, roles, credentials, fatigue, schedule.</div>
          </div>
          <div className="dt-col rust" style={{ padding: 32, gap: 8 }}>
            <div className="colhead">Mode B</div>
            <div className="dt-h3" style={{ fontSize: 30 }}>Plant + labour</div>
            <div className="dt-body-text" style={{ fontSize: 18 }}>Everything above, plus equipment and asset register.</div>
          </div>
        </div>
        <Boundary>You can switch later. The portal reconfigures around the mode.</Boundary>
      </div>
    </Slide>
  );
}

function C6S3() {
  const cats = [
    "HRWL · Crane operator",
    "HRWL · Dogger",
    "HRWL · Rigger Basic",
    "Working at Heights",
    "EWP · Boom · Scissor",
    "Civil construction VOC",
    "Rail · trackside",
    "Energy · LV / HV",
    "Confined space"
  ];
  return (
    <Slide carousel={6} slideNum={3} total={C6_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Step 02</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>
          Select the requirements<br/>your business <span className="dt-rust">actually uses.</span>
        </h2>
        <div className="dt-panel inset" style={{ padding: 32 }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)", marginBottom: 18 }}>
            COMPANY REQUIREMENT CATALOGUE
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {cats.map((c, i) => (
              <Tag key={c} tone={i < 5 ? "rust" : undefined}>
                {i < 5 ? "✓ " : "+ "}{c}
              </Tag>
            ))}
          </div>
          <div className="dt-mono" style={{ fontSize: 14, marginTop: 24, color: "var(--steel-soft)" }}>
            Job intake will show only the requirements you enable. Anything else stays one-off.
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C6S4() {
  return (
    <Slide carousel={6} slideNum={4} total={C6_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Step 03</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>Add workers.</h2>
        <div className="dt-panel" style={{ padding: 0 }}>
          {[
            ["L. Henderson", "Rigger · Dogger · EWP", "HRWL · WAH · EWP"],
            ["S. Marriot", "Crane Operator · Dogger", "HRWL · 100T · VOC"],
            ["B. Tahi", "Rigger · Trades Assist", "HRWL · WAH"],
            ["K. Pollard", "Dogger", "HRWL — expired"]
          ].map(([n, r, c], i) => (
            <div key={i} style={{ padding: "22px 32px", borderBottom: i < 3 ? "1px solid var(--hairline)" : "none", display: "flex", justifyContent: "space-between", alignItems: "center", gap: 24 }}>
              <span style={{ fontSize: 24, color: "var(--cream)" }}>{n}</span>
              <span style={{ fontSize: 18, color: "var(--cream-dim)", flex: 1, marginLeft: 32 }}>{r}</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 14, color: i === 3 ? "var(--block)" : "var(--steel)", letterSpacing: "0.06em" }}>{c}</span>
            </div>
          ))}
        </div>
        <Boundary>Worker import accepts paste, .txt, .md, or manual entry. Archive is safe and non-destructive.</Boundary>
      </div>
    </Slide>
  );
}

function C6S5() {
  return (
    <Slide carousel={6} slideNum={5} total={C6_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Step 04</Eyebrow>
        <h2 className="dt-display md">
          Add assets <span className="dt-steel">only</span><br/>if you use plant.
        </h2>
        <div className="dt-panel" style={{ marginTop: 56, padding: 32, maxWidth: 880 }}>
          <div className="dt-mono" style={{ fontSize: 14, letterSpacing: "0.12em", color: "var(--steel)", marginBottom: 18 }}>ASSET REGISTER</div>
          {[
            ["20T MOBILE CRANE", "MC20-001 · MC20-002"],
            ["100T MOBILE CRANE", "MC100-002"],
            ["EWP · 26m KNUCKLE", "EWP26-014"]
          ].map(([cls, ids], i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "14px 0", borderBottom: i < 2 ? "1px dashed var(--hairline)" : "none" }}>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 16, letterSpacing: "0.06em", color: "var(--cream)" }}>{cls}</span>
              <span style={{ fontFamily: "var(--font-mono)", fontSize: 16, color: "var(--rust)" }}>{ids}</span>
            </div>
          ))}
        </div>
        <p className="dt-lead" style={{ marginTop: 24, maxWidth: 720, fontSize: 22 }}>
          Class is one thing. Plant number is another. Both can live on the job.
        </p>
      </div>
    </Slide>
  );
}

function C6S6() {
  return (
    <Slide carousel={6} slideNum={6} total={C6_TOTAL}>
      <div className="dt-body">
        <Eyebrow>Step 05</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 40 }}>Create your first job.</h2>
        <div className="dt-panel" style={{ padding: 32 }}>
          <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
            <Tag tone="rust">JOB BRIEF IMPORT</Tag>
            <Tag>JOB ROLES</Tag>
            <Tag>EQUIPMENT</Tag>
            <Tag>SCHEDULE</Tag>
            <Tag>CONDITIONS</Tag>
          </div>
          <div style={{ padding: 24, background: "var(--charcoal)", border: "1px solid var(--hairline)", borderRadius: 4, fontFamily: "var(--font-mono)", fontSize: 17, color: "var(--cream-dim)", lineHeight: 1.5 }}>
            "Need 2 riggers + dogger Thursday 0630, 100T mob crane, counterweight tight, escort vehicle from Ipswich."
          </div>
          <div className="dt-mono" style={{ marginTop: 18, color: "var(--steel)", fontSize: 14, letterSpacing: "0.1em" }}>
            → 7 FIELDS SUGGESTED · 2 REVIEW FLAGS · DISPATCHER CONFIRMS
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C6S7() {
  return (
    <Slide carousel={6} slideNum={7} total={C6_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Step 06</Eyebrow>
        <h2 className="dt-display md">
          Run SmartRank.<br/>Review the <span className="dt-rust">trail.</span>
        </h2>
        <div className="dt-chain" style={{ marginTop: 64, maxWidth: 720 }}>
          {[
            ["SmartRank ranks workers", true],
            ["Warnings & blocks shown", true],
            ["Dispatcher reviews", true],
            ["Allocation confirmed", true],
            ["Audit recorded", true]
          ].map(([t, on], i) => (
            <div className="step on" key={i}>
              <span className="bullet" />
              <span className="dt-h3" style={{ fontSize: 28 }}>{t}</span>
            </div>
          ))}
        </div>
      </div>
    </Slide>
  );
}

function C6S8() {
  return (
    <Slide carousel={6} slideNum={8} total={C6_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">A managed pilot,<br/><span className="dt-rust">not cheap self-serve.</span></h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          Pilot pricing is discussed after workflow fit and support scope are understood. The first conversation is about your dispatch reality, not the software.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="Send context first" />
        </div>
      </div>
    </Slide>
  );
}

window.C6 = { slides: [C6S1, C6S2, C6S3, C6S4, C6S5, C6S6, C6S7, C6S8], title: "Build My Business", id: "carousel-06-build-my-business" };
