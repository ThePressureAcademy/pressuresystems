/* global React, Slide, Tag, Eyebrow, Boundary, CtaBlock, Ticker */
// Carousel 4 — Why Allocation Decisions Need a Trail

const C4_TOTAL = 8;

function C4S1() {
  return (
    <Slide carousel={4} slideNum={1} total={C4_TOTAL} bigMark>
      <div className="dt-body center">
        <Eyebrow>04 · Audit trail</Eyebrow>
        <h1 className="dt-display lg">
          Why was this<br/>worker <span className="dt-rust">selected?</span>
        </h1>
        <p className="dt-lead" style={{ marginTop: 56, maxWidth: 760 }}>
          A simple question. In most businesses, the answer lives in someone's head.
        </p>
      </div>
    </Slide>
  );
}

function C4S2() {
  return (
    <Slide carousel={4} slideNum={2} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The default state</Eyebrow>
        <h2 className="dt-display md">
          The answer lives<br/>in someone's <span className="dt-rust">head.</span>
        </h2>
        <div style={{ marginTop: 80, padding: 40, border: "1px solid var(--hairline-strong)", borderRadius: 6, maxWidth: 800, background: "var(--charcoal-deep)" }}>
          <div className="dt-mono" style={{ fontSize: 16, letterSpacing: "0.1em", color: "var(--steel)", marginBottom: 18 }}>
            EMAIL · 9 DAYS LATER · TO DISPATCH LEAD
          </div>
          <div className="dt-h3" style={{ fontSize: 30, color: "var(--cream)", lineHeight: 1.35 }}>
            "Mate, can you remind me why we sent Henderson and not Pollard to the Ipswich job on the 7th? Client asked."
          </div>
        </div>
      </div>
    </Slide>
  );
}

function C4S3() {
  return (
    <Slide carousel={4} slideNum={3} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The stress test</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 80 }}>
          That works until<br/>
          <span className="dt-steel">the day changes,</span><br/>
          <span className="dt-steel">pressure rises,</span><br/>
          or <span className="dt-rust">someone asks why.</span>
        </h2>
      </div>
    </Slide>
  );
}

function C4S4() {
  return (
    <Slide carousel={4} slideNum={4} total={C4_TOTAL}>
      <div className="dt-body">
        <Eyebrow>What DispatchTalon does</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 48 }}>The decision path<br/><span className="dt-rust">is recorded.</span></h2>
        <div className="dt-panel inset framed" style={{ padding: 32 }}>
          <Ticker rows={[
            ["06:42", "Job brief imported · J-2407", false],
            ["06:43", "Requirements confirmed by Dispatcher", false],
            ["06:44", "SmartRank generated · 8 candidates", true],
            ["06:45", "CredentialGate · 1 block", false],
            ["06:45", "FatigueGuard · 2 warnings", false],
            ["06:47", "Override reason captured", true],
            ["06:48", "Allocation confirmed · Henderson", true],
            ["06:48", "Audit event #ovr-44128 written", false]
          ]} />
        </div>
      </div>
    </Slide>
  );
}

function C4S5() {
  const chain = ["Job requirements", "Warnings", "SmartRank", "Overrides", "Allocation"];
  return (
    <Slide carousel={4} slideNum={5} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What is recorded</Eyebrow>
        <h2 className="dt-h2" style={{ marginBottom: 64 }}>Every link in the chain.</h2>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "center", maxWidth: 940 }}>
          {chain.map((c, i) => (
            <React.Fragment key={i}>
              <div className="dt-tag" style={{ height: 64, fontSize: 20, padding: "0 24px", background: "var(--graphite)", border: "1px solid var(--hairline-strong)" }}>
                <span style={{ color: "var(--rust)", marginRight: 8 }}>0{i + 1}</span>
                <span style={{ color: "var(--cream)" }}>{c}</span>
              </div>
              {i < chain.length - 1 && <span style={{ color: "var(--steel)", fontFamily: "var(--font-mono)", fontSize: 24 }}>→</span>}
            </React.Fragment>
          ))}
        </div>
        <p className="dt-lead" style={{ marginTop: 72, maxWidth: 720, fontSize: 26 }}>
          Not a screenshot. A structured trail of what the system saw, what it flagged, and what the dispatcher chose.
        </p>
      </div>
    </Slide>
  );
}

function C4S6() {
  return (
    <Slide carousel={4} slideNum={6} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>The boundary</Eyebrow>
        <div className="dt-quote">
          <span className="mark">"</span>The audit trail<br/>does not remove<br/>judgement.<br/>
          <span className="dt-rust">It preserves it.</span>
        </div>
      </div>
    </Slide>
  );
}

function C4S7() {
  return (
    <Slide carousel={4} slideNum={7} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>What you get back</Eyebrow>
        <h2 className="dt-display sm" style={{ fontSize: 84 }}>
          Better evidence.<br/>
          Better review.<br/>
          <span className="dt-rust">Better handover.</span>
        </h2>
        <div style={{ marginTop: 64, display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 18, maxWidth: 900 }}>
          {[
            ["Evidence", "Show the reasoning when a client asks."],
            ["Review", "Look back at last week's pattern, not just feeling."],
            ["Handover", "A new dispatcher inherits the trail, not the rumour."]
          ].map(([t, d], i) => (
            <div key={i} className="dt-panel" style={{ padding: 24, textAlign: "left" }}>
              <div className="dt-mono" style={{ fontSize: 13, letterSpacing: "0.14em", color: "var(--rust)" }}>0{i+1}</div>
              <div className="dt-h3" style={{ fontSize: 28, marginTop: 14 }}>{t}</div>
              <div className="dt-body-text" style={{ fontSize: 18, marginTop: 10 }}>{d}</div>
            </div>
          ))}
        </div>
        <Boundary>This is not a compliance guarantee. It is structured pilot proof of how the decision was made.</Boundary>
      </div>
    </Slide>
  );
}

function C4S8() {
  return (
    <Slide carousel={4} slideNum={8} total={C4_TOTAL}>
      <div className="dt-body center">
        <Eyebrow>Next step</Eyebrow>
        <h2 className="dt-display md">See the <span className="dt-rust">audit trail</span><br/>on a real job.</h2>
        <p className="dt-lead" style={{ marginTop: 32, maxWidth: 720 }}>
          15 minutes. We'll walk one allocation through job brief → SmartRank → warnings → override → audit, end to end.
        </p>
        <div style={{ marginTop: 56, maxWidth: 560 }}>
          <CtaBlock primary="Book a discovery call" secondary="See the audit trail walkthrough" />
        </div>
      </div>
    </Slide>
  );
}

window.C4 = { slides: [C4S1, C4S2, C4S3, C4S4, C4S5, C4S6, C4S7, C4S8], title: "Why Allocation Decisions Need a Trail", id: "carousel-04-audit-trail" };
