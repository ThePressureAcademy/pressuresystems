/* global React, ReactDOM, DesignCanvas, DCSection, DCArtboard, C1, C2, C3, C4, C5, C6, C7, C8, STRATEGY */

const CAROUSELS = [
  { meta: C1, audience: "Operations managers · dispatch managers · business owners" },
  { meta: C2, audience: "Buyers cautious about AI · senior dispatchers" },
  { meta: C3, audience: "Mixed crane + labour businesses evaluating fit" },
  { meta: C4, audience: "Commercial buyers · audit-minded operators" },
  { meta: C5, audience: "Technical evaluators · sceptical of \"AI\" claims" },
  { meta: C6, audience: "Pilot-curious operators · onboarding decision-makers" },
  { meta: C7, audience: "Crane company owners · yard managers · plant allocators" },
  { meta: C8, audience: "Senior crane operators · lift planners · safety-minded buyers" }
];

const PURPOSES = {
  1: "Educate on Job Brief Import. Show the gap between a phone call and a structured job.",
  2: "Establish the trust boundary up front: dispatcher remains the decision-maker.",
  3: "Show product flexibility: labour-only vs plant + labour modes.",
  4: "Build commercial trust via the audit trail and decision-path recording.",
  5: "Demystify SmartRank — six signals, blocks visible, dispatcher decides.",
  6: "Walk through clean first-run setup (Build My Business).",
  7: "Differentiate class from plant number; show asset register depth.",
  8: "Surface counterweight / transport / road-access review without overclaiming."
};

function CarouselSection({ idx }) {
  const { meta, audience } = CAROUSELS[idx];
  const num = idx + 1;
  return (
    <DCSection
      id={meta.id}
      title={`Carousel ${String(num).padStart(2,"0")} · ${meta.title}`}
      subtitle={`${audience} — ${PURPOSES[num]}`}
    >
      {meta.slides.map((Slide, i) => (
        <DCArtboard
          key={i}
          id={`${meta.id}-s${i + 1}`}
          label={`Slide ${String(i + 1).padStart(2, "0")}`}
          width={1080}
          height={1350}
        >
          <Slide />
        </DCArtboard>
      ))}
    </DCSection>
  );
}

function StrategySection() {
  const items = [
    ["strategy-master", "Master strategy", 1200, 1900, STRATEGY.MasterStrategy],
    ["strategy-brandkit", "Locked brand kit", 1200, 2400, STRATEGY.BrandKit],
    ["strategy-designsys", "Design system", 1200, 2100, STRATEGY.DesignSystemCard],
    ["strategy-claims", "Claim boundaries", 1200, 1800, STRATEGY.ClaimBoundaries],
    ["strategy-production", "Production checklist", 1200, 1700, STRATEGY.ProductionChecklist],
    ["strategy-reuse", "Crop & reuse", 1200, 1600, STRATEGY.ReuseGuide],
    ["strategy-shortform", "Short-form cutdowns", 1200, 1900, STRATEGY.ShortForm],
    ["strategy-gaps", "Asset gaps", 1200, 1500, STRATEGY.AssetGaps],
    ["strategy-captions", "LinkedIn captions", 1200, 2900, STRATEGY.Captions]
  ];
  return (
    <DCSection
      id="strategy"
      title="Strategy, captions & QA"
      subtitle="Master notes · captions · CTA bank · claim boundaries · production checklist · short-form cutdowns · asset gaps"
    >
      {items.map(([id, label, w, h, Comp]) => (
        <DCArtboard key={id} id={id} label={label} width={w} height={h}>
          <Comp />
        </DCArtboard>
      ))}
      <DCArtboard id="strategy-ctabank" label="CTA bank" width={1200} height={1800}>
        <STRATEGY.CtaBank />
      </DCArtboard>
    </DCSection>
  );
}

function CoverSection() {
  return (
    <DCSection
      id="cover"
      title="DispatchTalon · LinkedIn carousel system"
      subtitle="8 carousels · 64 slides · 1080×1350 · plus strategy, captions, CTA bank, claim boundaries, production checklist, short-form cutdowns, and outstanding-asset list"
    >
      <DCArtboard id="cover-card" label="Read me first" width={1200} height={1000}>
        <div className="dt-slide" style={{ width: 1200, height: 1000 }}>
          <TalonMark size={720} className="dt-mark huge" />
          <TalonMark size={64} className="dt-mark" />
          <div className="dt-head">
            <span><span className="dot" />DispatchTalon</span>
          </div>
          <div className="dt-body center">
            <img src="assets/logos/dispatchtalon/dispatchtalon-header-lockup-transparent.png" alt="DispatchTalon by Pressure Systems" style={{ height: 110, width: "auto", marginBottom: 40 }} />
            <Eyebrow>LinkedIn carousel system · v1</Eyebrow>
            <h2 className="dt-display sm" style={{ fontSize: 60 }}>
              Eight carousels, ready to ship.<br/>
              One <span className="dt-rust">strategy section</span> at the end.
            </h2>
            <p className="dt-lead" style={{ marginTop: 28, maxWidth: 900, fontSize: 22 }}>
              Each row below is one LinkedIn carousel at native 1080×1350. Drag the canvas to pan, scroll to zoom. Click any artboard's expand icon to view it full-screen — that view is what an export PNG will look like.
            </p>
            <div style={{ marginTop: 28, display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "center", maxWidth: 1000 }}>
              {["C01 · Job intake", "C02 · Dispatcher decides", "C03 · Operating modes", "C04 · Audit trail", "C05 · SmartRank", "C06 · Build My Business", "C07 · Plant numbers", "C08 · Counterweight + transport", "Strategy · captions · QA · brand kit"].map((t, i) => (
                <Tag key={i} tone={i === 8 ? "rust" : undefined}>{t}</Tag>
              ))}
            </div>
          </div>
          <div className="dt-foot">
            <span>DispatchTalon <strong>by Pressure Systems</strong></span>
            <span>Pilot-stage workflow · Dispatcher-led review</span>
          </div>
        </div>
      </DCArtboard>
    </DCSection>
  );
}

function App() {
  return (
    <DesignCanvas>
      <CoverSection />
      {CAROUSELS.map((_, i) => <CarouselSection key={i} idx={i} />)}
      <StrategySection />
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
